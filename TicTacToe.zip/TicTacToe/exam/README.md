Before Running use this command:
- yarn install

HOW TO RUN FRONTEND:
- yarn run start

HOW TO RUN BACKEND:
- yarn run express