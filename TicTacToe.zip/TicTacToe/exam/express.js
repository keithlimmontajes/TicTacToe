var express = require('express');
var mysql = require('mysql');
var cors = require('cors');
const bodyParser = require('body-parser');

var app = express();
var port = 3002;

var connection = mysql.createConnection({
    host : "localhost",
    user : "root",
    password : "",
    database : "tictactoe"
});

app.use(cors());
app.use(bodyParser.json());
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

app.post('/create/history', (req, res) => {
    console.log(req.body)
    const query = "INSERT INTO history (name, score) VALUES (" + '"' + req.body.name + '"' + "," + '"' + req.body.score + '"' + ")" ;
    connection.query(query, function(err, rows, fields) {
        res.json(rows)
    })
})

app.get('/get/history', (req, res) => {
    const query = "SELECT * from history";
    connection.query(query, function(err, rows, fields) {
        res.json(rows)
    })
})