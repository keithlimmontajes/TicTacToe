import React, { useState } from "react";
import { getHistory, creteaHistory  } from '../utils';
import { calculateWinner } from "../helpers";
import Board from "../components/board";
import Table from '../components/table';

const Game = () => {
  const [history, setHistory] = useState([Array(9).fill(null)]);
  const [stepNumber, setStepNumber] = useState(0);
  const [xIsNext, setXisNext] = useState(true);
  const [item, setData] = useState([])
  const [players, setPlayers] = useState({
    player_1: "",
    player_2: "",
  })

  React.useEffect(() => {
    getHistory(setData);
  }, [])

  const winner = calculateWinner(history[stepNumber]);

  const nextPlayer = xIsNext ? "X" : "O";

  const handleClick = (i) => {
    const historyPoint = history.slice(0, stepNumber + 1);
    const current = historyPoint[stepNumber];
    const squares = [...current];
    if (winner || squares[i]) return;
    squares[i] = nextPlayer;
    setHistory([...historyPoint, squares]);
    setStepNumber(historyPoint.length);
    setXisNext(!xIsNext);
  };

  
  const create = () => {
    const score = winner === null &&  history.length === 10? "Draw game" : "1";
    const name =  winner === "X" ? players.player_1 : players.player_2;
    creteaHistory(name, score);
  }

  const jumpTo = (step) => {
    setStepNumber(step);
    setXisNext(step % 2 === 0);
  };

  const renderMoves = () => {
    jumpTo(0);

    if(winner || history.length === 10){
      create();
    }
  };

  return (
    <>
      <Board squares={history[stepNumber]} onClick={handleClick} />
      <div style={{ padding: 10}}>
        <input placeholder="player 1" style={{ padding: 10}} onChange ={(e)=>setPlayers({ ...players, player_1: e.target.value})} value={players.player_1}/>
        <input placeholder="player 2" style={{ padding: 10, margin: '0px 20px 0px 20px'}} onChange ={(e)=>setPlayers({ ...players, player_2: e.target.value})} value={players.player_2}/>
        <button onClick={() => setPlayers({ player_1: "", player_2: "" })} style={{ padding: 10}}>Clear</button>
      </div>

      <div className="info-wrapper">
        <div>
         <button onClick={() => renderMoves()}>RESTART</button>
        </div>
        <h3>{winner === null &&  history.length === 10 ? "DRAW GAME" : winner ? winner === "X" ? `Winner: ${players.player_1}` : `Winner: ${players.player_2}` : xIsNext ? `Next Player: ${players.player_1}` :  `Next Player: ${players.player_2}`}</h3>
      </div>

      <Table data={item}/>
    </>
  );
};

export default Game;
