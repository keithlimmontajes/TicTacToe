import React from 'react'

 const Table = (props) => {
    const data = props.data;
    const [show, setShow] = React.useState(false)

    return (
        <table border ={1} style={{ width: '100%'}}>
            <tr>
                <th>Place</th>
                <th>Name</th>
                <th>Score</th>
            </tr>
              
            {data.map((item, index) => 
              <tr key ={index}>
                <td>{index+1}</td>
                <td>{item.name}</td>
                <td>{item.score}</td>
            </tr>
            )}
        </table>
    )
}

export default Table;