import axios from 'axios';

export const getHistory = async (setData) => {
    const call = await axios.get('http://localhost:3002/get/history')
    .then(res => {
        const item = res.data.sort((a, b) => b.score - a.score);
        setData(item)
    })
    .catch(err => console.log(err))
}

export const creteaHistory  = async (name, score) => {
    console.log(name)
    const call = await axios.post('http://localhost:3002/create/history',{
        name: name.length === 0 ? "player" : name,
        score: score
    })
    .then(res => console.log(res))
    .catch(err => console.log(err))
}
